const $ = (s, e = document) => e.querySelector(s);
const $$ = (s, e = document) => Array.from(e.querySelectorAll(s));
const LEVELS = { recruiter: 0, normal: 1, deep: 2 };

function setView(view) {
  document.body.dataset.view = view;
  localStorage.setItem("portfolio_view", view);
  $$("[data-view-btn]").forEach(btn => {
    const on = btn.dataset.viewBtn === view;
    btn.classList.toggle("is-active", on);
    btn.setAttribute("aria-selected", String(on));
  });

  if (view === "freelance") {
    // Curated view: ignore level hierarchy, hide sections marked as not relevant for freelance clients.
    $$("[data-min-level]").forEach(el => { el.dataset.hidden = "false"; });
    $$("[data-freelance-hide]").forEach(el => { el.dataset.hidden = "true"; });
    return;
  }

  const current = LEVELS[view] ?? 1;
  $$("[data-min-level]").forEach(el => {
    const min = Number(el.getAttribute("data-min-level") || "0");
    el.dataset.hidden = String(current < min);
  });
  // Reset any freelance-only hiding inherited from a previous switch.
  $$("[data-freelance-hide]").forEach(el => {
    if (!el.hasAttribute("data-min-level")) el.dataset.hidden = "false";
  });

  // El plegado depende de qué cards son visibles en la vista activa,
  // así que se recalcula después de aplicar los niveles.
  applyProjectGroups();
}

// ── Grupos plegables de #proyectos ─────────────────────────────────
// Cada grupo muestra PREVIEW cards y esconde el resto. Se cuenta solo
// sobre las cards visibles en la vista actual: si "Profundo" añade
// cards de nivel 2, el contador del botón las incluye.
const GROUP_PREVIEW = 4;

function applyProjectGroups() {
  $$(".project-group").forEach(group => {
    const open = group.dataset.open === "true";
    const cards = $$("article.card.project", group)
      .filter(card => card.dataset.hidden !== "true");

    cards.forEach((card, i) => {
      card.dataset.collapsed = String(!open && i >= GROUP_PREVIEW);
    });

    const ocultas = Math.max(0, cards.length - GROUP_PREVIEW);
    const toggle = $(".project-group__toggle", group);
    if (!toggle) return;
    // Un grupo que cabe entero no necesita botón.
    toggle.dataset.hidden = String(ocultas === 0);
    toggle.setAttribute("aria-expanded", String(open));
    $$(".js-count", toggle).forEach(el => { el.textContent = String(ocultas); });
  });
  // Las cards recién mostradas ya tienen altura: ahora se puede saber
  // cuáles quedan recortadas.
  if (typeof markClampedDescriptions === "function") markClampedDescriptions();
}

function initProjectGroups() {
  $$(".project-group__toggle").forEach(toggle => {
    toggle.addEventListener("click", () => {
      const group = toggle.closest(".project-group");
      if (!group) return;
      group.dataset.open = group.dataset.open === "true" ? "false" : "true";
      applyProjectGroups();
    });
  });
  applyProjectGroups();
}

// ── Descripciones recortadas ───────────────────────────────────────
// El CSS recorta a 2 líneas; el texto completo permanece en el DOM.
// Solo se vuelve pulsable la descripción que de verdad está recortada,
// y eso solo puede medirse cuando la card es visible: una card plegada
// mide 0. Por eso se re-evalúa cada vez que cambia lo visible.
function markClampedDescriptions() {
  $$("article.card.project > p").forEach(p => {
    if (p.dataset.clampChecked === "done" || p.offsetParent === null) return;
    if (p.scrollHeight <= p.clientHeight + 1) return;   // cabe entera: no se toca
    p.dataset.clampChecked = "done";
    p.setAttribute("role", "button");
    p.setAttribute("tabindex", "0");
    p.setAttribute("aria-expanded", "false");
  });
}

// Delegación: las cards aparecen y desaparecen al plegar o cambiar de
// vista, así que el listener vive en el documento y no en cada <p>.
function initCardDescriptions() {
  const toggle = p => {
    const card = p.closest("article.card.project");
    if (!card) return;
    const open = card.classList.toggle("is-open");
    p.setAttribute("aria-expanded", String(open));
  };
  document.addEventListener("click", ev => {
    const p = ev.target.closest?.('article.card.project > p[role="button"]');
    if (p) toggle(p);
  });
  document.addEventListener("keydown", ev => {
    if (ev.key !== "Enter" && ev.key !== " ") return;
    const p = ev.target.closest?.('article.card.project > p[role="button"]');
    if (p) { ev.preventDefault(); toggle(p); }
  });
  markClampedDescriptions();
}

function setTheme(theme) {
  document.body.dataset.theme = theme;
  localStorage.setItem("portfolio_theme", theme);
  const icon = $("#themeIcon");
  if (icon) icon.textContent = theme === "dark" ? "🌙" : "☀️";
}

function toggleTheme() {
  const cur = document.body.dataset.theme || "dark";
  setTheme(cur === "dark" ? "light" : "dark");
}

function setLang(lang) {
  document.body.dataset.lang = lang;
  localStorage.setItem("portfolio_lang", lang);
  const sel = $("#selectLang");
  if (sel) sel.value = lang;
  updateLocalizedPdfLinks(lang);
}

function resolveLocalizedPdfHref(link, lang) {
  const fallback = link.dataset.pdfEs || link.getAttribute("href") || "#";
  const key = "pdf" + lang.charAt(0).toUpperCase() + lang.slice(1);
  return link.dataset[key] || fallback;
}

function updateLocalizedPdfLinks(lang) {
  $$("[data-pdf-link]").forEach(link => {
    link.setAttribute("href", resolveLocalizedPdfHref(link, lang));
  });
}

function handleLangChange(e) {
  setLang(e.target.value);
}

function detectLang() {
  const saved = localStorage.getItem("portfolio_lang");
  if (saved) return saved;
  const supported = ["es", "en", "pt", "it", "fr", "zh"];
  const browser = (navigator.language || navigator.languages?.[0] || "es")
    .toLowerCase().slice(0, 2);
  return supported.includes(browser) ? browser : "es";
}

// Bump cuando se agregue/cambie el set de vistas — fuerza que los visitantes
// con localStorage viejo vuelvan al default (recruiter) la primera vez que
// carguen la versión nueva. Después la persistencia funciona normalmente.
const VIEW_SCHEMA = "2026-06-20-freelance";

function initSettings() {
  if (localStorage.getItem("portfolio_view_schema") !== VIEW_SCHEMA) {
    localStorage.removeItem("portfolio_view");
    localStorage.setItem("portfolio_view_schema", VIEW_SCHEMA);
  }
  setView(localStorage.getItem("portfolio_view") || "recruiter");
  setTheme(localStorage.getItem("portfolio_theme") || "dark");
  setLang(detectLang());

  $$("[data-view-btn]").forEach(btn => btn.addEventListener("click", () => setView(btn.dataset.viewBtn)));
  $("#btnTheme")?.addEventListener("click", toggleTheme);
  $("#selectLang")?.addEventListener("change", handleLangChange);

  initProjectGroups();
  initCardDescriptions();
}

function initMenu() {
  const btn = $("#btnMenu");
  const nav = $("#nav");
  if (!btn || !nav) return;
  const overlay = $("#drawerOverlay");

  // El sidebar es panel fijo en escritorio y drawer en movil: el mismo
  // .is-open sirve para ambos porque en >=1024px el media query lo ignora.
  const setOpen = open => {
    nav.classList.toggle("is-open", open);
    btn.setAttribute("aria-expanded", String(open));
    document.body.classList.toggle("drawer-open", open);
    if (overlay) overlay.hidden = !open;
  };

  btn.addEventListener("click", () => setOpen(!nav.classList.contains("is-open")));
  overlay?.addEventListener("click", () => setOpen(false));
  document.addEventListener("keydown", e => {
    if (e.key === "Escape" && nav.classList.contains("is-open")) setOpen(false);
  });
  $$("a", nav).forEach(a => a.addEventListener("click", () => setOpen(false)));
}

async function loadRecentRepos() {
  const box = $("#recentRepos");
  if (!box) return;
  const ghUrl = "https://api.github.com/users/vladimiracunadev-create/repos?per_page=12&sort=updated";
  const glUrl = "https://gitlab.com/api/v4/groups/vladimir.acuna.dev-group/projects?per_page=12&order_by=last_activity_at&sort=desc";
  try {
    const [ghRes, glRes] = await Promise.all([
      fetch(ghUrl, { headers: { "Accept": "application/vnd.github+json" } }),
      fetch(glUrl, { headers: { "Accept": "application/json" } })
    ]);

    let repos = [];

    if (ghRes.ok) {
      const ghData = await ghRes.json();
      repos.push(...ghData.map(r => ({
        name: r.name,
        url: r.html_url,
        desc: (r.description || "").replace(/</g, "&lt;").replace(/>/g, "&gt;"),
        stars: r.stargazers_count,
        forks: r.forks_count,
        pushed: r.pushed_at,
        isFork: r.fork,
        source: "GH"
      })));
    }

    if (glRes.ok) {
      const glData = await glRes.json();
      repos.push(...glData.map(r => ({
        name: r.name,
        url: r.web_url,
        desc: (r.description || "").replace(/</g, "&lt;").replace(/>/g, "&gt;"),
        stars: r.star_count,
        forks: r.forks_count,
        pushed: r.last_activity_at,
        isFork: !!r.forked_from_project,
        source: "GL"
      })));
    }

    repos = repos.sort((a, b) => new Date(b.pushed) - new Date(a.pushed)).slice(0, 12);
    if (!repos.length) throw new Error("empty");

    box.innerHTML = repos.map(r => {
      const updated = new Date(r.pushed).toLocaleDateString("es-CL", { year: "numeric", month: "short", day: "2-digit" });
      const forkBadge = r.isFork ? ' · <span title="Fork">⑂ fork</span>' : "";
      const sourceBadge = `<span class="pill mini" title="${r.source === "GL" ? "GitLab" : "GitHub"}">${r.source}</span>`;
      return `
          <div class="repo">
            <div class="repo__top">
              <a class="repo__name" href="${r.url}" target="_blank" rel="noreferrer">${r.name}</a> ${sourceBadge}
              <div class="repo__meta">★ ${r.stars} · ⑂ ${r.forks} · ${updated}${forkBadge}</div>
            </div>
            ${r.desc ? `<div class="repo__desc">${r.desc}</div>` : ""}
          </div>`;
    }).join("");
  } catch (e) {
    box.innerHTML = `<div class="muted small">No se pudo cargar la lista. Ver repos en <a href="https://github.com/vladimiracunadev-create" target="_blank" rel="noreferrer">GitHub</a> y <a href="https://gitlab.com/vladimir.acuna.dev-group" target="_blank" rel="noreferrer">GitLab</a>.</div>`;
  }
}

function timeAgo(dateStr) {
  const diff = Date.now() - new Date(dateStr).getTime();
  const days = Math.floor(diff / 86400000);
  const hours = Math.floor(diff / 3600000);
  const mins = Math.floor(diff / 60000);
  if (days > 30) return new Date(dateStr).toLocaleDateString("es-CL", { month: "short", day: "2-digit", year: "numeric" });
  if (days > 0) return `hace ${days}d`;
  if (hours > 0) return `hace ${hours}h`;
  return `hace ${mins}m`;
}

async function loadRecentActivity() {
  const box = $("#recentActivity");
  if (!box) return;
  const ghUrl = "https://api.github.com/users/vladimiracunadev-create/events?per_page=50";
  const glUrl = "https://gitlab.com/api/v4/groups/vladimir.acuna.dev-group/merge_requests?state=merged&per_page=10&order_by=updated_at&sort=desc";
  try {
    const [ghRes, glRes] = await Promise.all([
      fetch(ghUrl, { headers: { "Accept": "application/vnd.github+json" } }),
      fetch(glUrl)
    ]);

    let totalCommits = 0, totalPRs = 0, totalReleases = 0;
    const activeRepos = new Set();
    const highlights = [];

    if (ghRes.ok) {
      const events = await ghRes.json();
      for (const e of events) {
        const repo = e.repo.name.replace("vladimiracunadev-create/", "");
        activeRepos.add(repo);
        if (e.type === "PushEvent") {
          totalCommits += e.payload.commits?.length || 1;
        } else if (e.type === "PullRequestEvent" && e.payload.pull_request?.merged) {
          totalPRs++;
          highlights.push({ icon: "🔀", label: `PR → ${repo}`,
            detail: e.payload.pull_request.title?.slice(0, 90) || "",
            date: e.created_at, source: "GH", url: e.payload.pull_request.html_url });
        } else if (e.type === "ReleaseEvent") {
          totalReleases++;
          highlights.push({ icon: "🚀", label: `release ${e.payload.release.tag_name} → ${repo}`,
            detail: e.payload.release.name?.slice(0, 90) || "",
            date: e.created_at, source: "GH", url: e.payload.release.html_url });
        } else if (e.type === "CreateEvent" && e.payload.ref_type === "tag") {
          highlights.push({ icon: "🏷", label: `tag ${e.payload.ref} → ${repo}`,
            detail: "", date: e.created_at, source: "GH", url: `https://github.com/${e.repo.name}` });
        }
      }
    }

    if (glRes.ok) {
      const mrs = await glRes.json();
      totalPRs += mrs.length;
      for (const mr of mrs) {
        const project = mr.web_url.split("/")[4] || "gitlab";
        activeRepos.add(project);
        highlights.push({ icon: "🔀", label: `MR → ${project}`,
          detail: mr.title?.slice(0, 90) || "",
          date: mr.merged_at || mr.updated_at, source: "GL", url: mr.web_url });
      }
    }

    if (!totalCommits && !highlights.length) throw new Error("empty");

    const stats = [
      totalCommits  ? `⬆ ${totalCommits} commits`  : null,
      totalPRs      ? `🔀 ${totalPRs} PRs / MRs`   : null,
      totalReleases ? `🚀 ${totalReleases} releases` : null,
      activeRepos.size ? `📦 ${activeRepos.size} repos` : null,
    ].filter(Boolean).map(s => `<span class="pill">${s}</span>`).join(" ");

    const top = highlights
      .sort((a, b) => new Date(b.date) - new Date(a.date))
      .slice(0, 6)
      .map(item => {
        const ago = timeAgo(item.date);
        const safeDet = item.detail.replace(/</g, "&lt;").replace(/>/g, "&gt;");
        const src = `<span class="pill mini">${item.source}</span>`;
        return `
          <div class="repo">
            <div class="repo__top">
              <a class="repo__name" href="${item.url}" target="_blank" rel="noreferrer">${item.icon} ${item.label}</a> ${src}
              <div class="repo__meta">${ago}</div>
            </div>
            ${safeDet ? `<div class="repo__desc">${safeDet}</div>` : ""}
          </div>`;
      }).join("");

    box.innerHTML = `<div class="chips chips--stats">${stats}</div>${top}`;
  } catch (e) {
    box.innerHTML = `<div class="muted small">No se pudo cargar la actividad.</div>`;
  }
}

function initCopyEmail() {
  const btn = $("#btnCopyEmail");
  if (!btn) return;
  btn.addEventListener("click", async () => {
    const email = "vladimir.acuna.dev@gmail.com";
    try {
      await navigator.clipboard.writeText(email);
      const old = btn.textContent;
      btn.textContent = "Copiado ✔";
      setTimeout(() => btn.textContent = old, 1200);
    } catch {
      prompt("Copia el email:", email);
    }
  });
}

// Emite los 6 <span data-XX> que espera el sistema de idiomas del sitio.
// Escribir textContent o un literal suelto deja ese texto en un solo idioma
// para los seis, porque styles.css decide que mostrar por atributo.
const LANGS = ["es", "en", "pt", "it", "fr", "zh"];
const i18n = dict => LANGS.map(l => `<span data-${l}>${dict[l]}</span>`).join("");

const DL_LABELS = {
  apk: { es: "Descargar APK", en: "Download APK", pt: "Baixar APK", it: "Scarica APK", fr: "Télécharger l'APK", zh: "下载 APK" },
  apkEmu: { es: "Descargar APK (Emulador)", en: "Download APK (Emulator)", pt: "Baixar APK (Emulador)", it: "Scarica APK (Emulatore)", fr: "Télécharger l'APK (Émulateur)", zh: "下载 APK（模拟器）" },
  pwa: { es: "Instalar PWA", en: "Install PWA", pt: "Instalar PWA", it: "Installa PWA", fr: "Installer la PWA", zh: "安装 PWA" },
  pwaDesktop: { es: "Instalar PWA (Desktop)", en: "Install PWA (Desktop)", pt: "Instalar PWA (Desktop)", it: "Installa PWA (Desktop)", fr: "Installer la PWA (Desktop)", zh: "安装 PWA（桌面）" },
  pwaApp: { es: "Instalar como App (PWA)", en: "Install as App (PWA)", pt: "Instalar como App (PWA)", it: "Installa come App (PWA)", fr: "Installer comme App (PWA)", zh: "安装为应用（PWA）" },
};

// El nombre de plataforma es un nombre propio: solo se traduce la frase.
const platformNotice = name => ({
  es: `Plataforma detectada: ${name}`, en: `Detected platform: ${name}`,
  pt: `Plataforma detectada: ${name}`, it: `Piattaforma rilevata: ${name}`,
  fr: `Plateforme détectée : ${name}`, zh: `检测到的平台：${name}`,
});

const UNKNOWN_NOTICE = {
  es: "Plataforma no identificada", en: "Platform not identified",
  pt: "Plataforma não identificada", it: "Piattaforma non identificata",
  fr: "Plateforme non identifiée", zh: "未识别的平台",
};

function initAppDownloads() {
  const actions = $("#smartDownloadActions");
  const notice = $("#platformNotice");
  if (!actions || !notice) return;

  const ua = navigator.userAgent;
  const isAndroid = /Android/i.test(ua);
  const isIOS = /iPhone|iPad|iPod/i.test(ua);
  const isMac = /Macintosh/i.test(ua) && !isIOS;
  const isWindows = /Windows/i.test(ua);

  // Configuración de URLs de Release
  const REPO_URL = "https://github.com/vladimiracunadev-create/vladimiracunadev-create.github.io/releases/latest/download";
  const APK_URL = `${REPO_URL}/app-debug.apk`;

  const apk = (label, primary) => `<a class="btn${primary ? " primary" : ""}" href="${APK_URL}">${i18n(label)}</a>`;
  const pwa = (label, primary) => `<button class="btn${primary ? " primary" : ""}" type="button" data-pwa-trigger>${i18n(label)}</button>`;

  let noticeDict, html;
  if (isAndroid) {
    noticeDict = platformNotice("Android");
    html = apk(DL_LABELS.apk, true);
  } else if (isIOS || isMac) {
    noticeDict = platformNotice(isIOS ? "iOS" : "macOS");
    html = pwa(DL_LABELS.pwaApp, true);
  } else if (isWindows) {
    noticeDict = platformNotice("Windows");
    html = pwa(DL_LABELS.pwaDesktop, true) + apk(DL_LABELS.apkEmu, false);
  } else {
    noticeDict = UNKNOWN_NOTICE;
    html = apk(DL_LABELS.apk, true) + pwa(DL_LABELS.pwa, false);
  }

  notice.innerHTML = i18n(noticeDict);
  actions.innerHTML = html;
}

function initPwaTriggers() {
  document.addEventListener("click", (e) => {
    if (e.target.closest("[data-pwa-trigger]")) {
      window.dispatchEvent(new Event("pwa-prompt"));
    }
  });
}

function initMeta() {
  const y = $("#year");
  if (y) y.textContent = String(new Date().getFullYear());
}

initSettings();
initMenu();
initCopyEmail();
initMeta();
initAppDownloads();
initPwaTriggers();
loadRecentRepos();
loadRecentActivity();
